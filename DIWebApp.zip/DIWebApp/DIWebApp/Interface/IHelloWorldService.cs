﻿namespace DIWebApp.Interface
{
    public interface IHelloWorldService
    {
        string SayHello();
    }
}
