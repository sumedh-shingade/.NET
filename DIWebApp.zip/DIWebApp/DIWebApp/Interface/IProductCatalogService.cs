﻿namespace DIWebApp.Interface
{
    public interface IProductCatalogService
    {
        //non static methods 
        bool Insert();
        bool Update();
        bool Delete();
     
    }
}
