﻿using DIWebApp.Interface;

namespace DIWebApp.Services
{
    public class ProductCatalog:IProductCatalogService
    {
        public ProductCatalog() { }

        public bool Insert()
        {
            //invoke Bll layer
            bool status = true;
            return status;
        }

        public bool Delete()
        {
            bool status =false;
            return status;
        }
        public bool Update() { 
        bool status = false;     
                    return status;
        }
    }
}
