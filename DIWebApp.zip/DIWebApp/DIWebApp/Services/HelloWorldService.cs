﻿using DIWebApp.Interface;

namespace DIWebApp.Services
{
    //each service should be defined by using contract
    public class HelloWorldService:IHelloWorldService
    {
        public HelloWorldService() {
            Console.WriteLine("HelloWorld Service instance Initialized....");
        }

        public string SayHello()
        {
            return "IET";
        }

    

    }
}
