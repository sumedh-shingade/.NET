﻿using DIWebApp.Interface;
using DIWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace DIWebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly IHelloWorldService _helloWorldService;
        private readonly IProductCatalogService _productCatalogService;


        //Constructor dependency Injection
        public HomeController(IHelloWorldService _helloWorldService,IProductCatalogService _productCatalogService)
        {
            Console.WriteLine("Home Controller instance is initialised");

            this._helloWorldService = _helloWorldService;
            this._productCatalogService = _productCatalogService;
        }

        public IActionResult Index()
        {
            Console.WriteLine("Homecontroller index method  is invoked");
            string message = this._helloWorldService.SayHello();
            ViewData["message"] = message;
            bool status = this._productCatalogService.Insert();
            return View();

                }

        public IActionResult Privacy()
        {
            Console.WriteLine("HomeController Privacy Method id invoked");
            string message = this._helloWorldService.SayHello();
            ViewData["message"] = message;
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}