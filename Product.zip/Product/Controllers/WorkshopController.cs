﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DayWiseSheduler.Models;
using DayWiseSheduler.DAL;

namespace DayWiseSheduler.Controllers
{
    public class WorkshopController : Controller
    {
       
        // GET: Workshop
        public ActionResult Index()
        {
            DataManager mgr = new DataManager();
            List<WorkShop> list=mgr.WorkShop.ToList();
            this.ViewData["workshop"] = list; 
            return View();
        }

        [Authorize]
        public ActionResult Insert()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Insert(WorkShop wrshop)
        {
            DataManager mgr = new DataManager();
            mgr.WorkShop.Add(wrshop);
            mgr.SaveChanges();
          return   RedirectToAction("index", "workshop"); 
        }

        [Authorize]
        public ActionResult Delete(int id)
        {
            DataManager mgr = new DataManager();
            WorkShop wrshop = mgr.WorkShop.ToList().Find((p) => (p.Id == id));
            mgr.WorkShop.Remove(wrshop);
            mgr.SaveChanges();
            return RedirectToAction("Index", "workshop");

        }

        [Authorize]
        public ActionResult Put(int id)
        {
            DataManager mgr = new DataManager();
            WorkShop wrshop = mgr.WorkShop.ToList().Find((p) => (p.Id == id));
            return View(wrshop);
        }


        [HttpPost]
        public ActionResult Put( WorkShop theWorshop)
        {
            DataManager mgr = new DataManager();
            /*  mgr.WorkShop.Remove(wrshop);
              mgr.WorkShop.Add(thewrshop);*/
            mgr.Entry(theWorshop).State = System.Data.Entity.EntityState.Modified;
            mgr.SaveChanges();
            return RedirectToAction("Index", "workshop");
        }

    }
}