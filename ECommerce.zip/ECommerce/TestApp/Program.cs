﻿using HR;
using Testing;


List<Department> departments=DBTestManager.GetAllDepartments();
foreach(Department dept in departments){
    Console.WriteLine(dept.Name + " " + dept.Location);
}