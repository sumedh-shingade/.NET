﻿using Microsoft.AspNetCore.Mvc;

namespace OnlineShopping.Controllers
{

    public class ProductsController : Controller
    {
        private readonly ILogger<ProductsController> _logger;

        public ProductsController(ILogger<ProductsController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult Products()
        {
            return View();
        }



    }
}
